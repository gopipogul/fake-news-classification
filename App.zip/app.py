from flask import Flask, abort, jsonify, request, render_template
import joblib
from feature import *
import json
import warnings
from newspaper import Article
import urllib
import nltk
import pickle
warnings.filterwarnings("ignore")

with open('model4.pkl', 'rb') as handle:
    pipeline = pickle.load(handle)
# pipeline = joblib.load('./pipeline.sav')

app = Flask(__name__)

@app.route('/newsify')
def home():
    return render_template('index1.html')

@app.route('/')
def homepage():
    return render_template('homepage.html')

@app.route('/team')
def team():
    return render_template('Team.html')

@app.route('/u')
def u():
    return render_template('url.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/api',methods=['POST'])
def get_delay():
    result=request.form
    query_title = result['title']
    query_author = result['author']
    query_text = result['maintext']
    print(query_text)
    query = get_all_query(query_title, query_author, query_text)
    user_input = {'query':query}
    pred = pipeline.predict(query)
    print(pred)
    dic = {1:'REAL',0:'FAKE'} 
    dic = {'REAL':1,'FAKE':0} 

    
    # return render_template('result.html')
    # return render_template("result.html", result = result,query_title = query_title, query_author = query_author,
    # query_text = query_text, query=query,pred = pred, dic=dic)

    return f'<html><body bgcolor="#088db9" text="orange"><font face="Bookman old style"><b><center><h1>{pred[0]}</h1><form action="/newsify"> <button type="submit">back </button></b></font></center></form></body></html>' 


@app.route('/url',methods=['POST'])
def get_delay_url():
    url = request.get_data(as_text=True)[5:]
    url = urllib.parse.unquote(url)
    article = Article(str(url))
    article.download()
    article.parse()
    article.nlp()
    news = article.summary
    print(news)
    pred = pipeline.predict([news])

    #dic = {1:'REAL',0:'FAKE'} 
    #return render_template('index1.html', prediction_text=f'The news is {pred[0]}',news=news)
    return f'<html><body bgcolor="#088db9" text="orange"><font face="Bookman old style"><b><center><h1>{pred[0]}</h1><form action="/u"> <button type="submit">back </button></b></font></center></form></body></html>'
    
    
    #return render_template('result.html')
    #return render_template("result.html", result = result,query_title = query_title, query_author = query_author,
    #query_text = query_text, query=query,pred = pred, dic=dic)

    # return f'<html><body bgcolor="#088db9" text="orange"><font face="Bookman old style"><b><center><h1>{dic[pred[0]]}</h1><form action="/"> <button type="submit">back </button></b></font></center></form></body></html>' 
   


if __name__ == '__main__':
    app.run(port=8082, debug=True)
